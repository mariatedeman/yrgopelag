<!-- # ISLAND INFO
#   {
#     "id": 212,
#     "islandName": "Lyckholmen",
#     "hotelName": "Sjöboda B&amp;amp;B",
#     "url": "https://made-by-met.se/yrgopelag/",
#     "stars": 2,
#     "owner": 19,
#     "hotel_specific_name": "coastal experiences"
#   }, -->