<?php

declare(strict_types=1);

/////////////////////////////////////////////////

// VALIDATE TRANSFER CODE
function isValidTransferCode(string $transferCode, int $totalCost): bool
{

    $url = 'https://www.yrgopelag.se/centralbank/transferCode';

    // PREPARE DATA TO SEND
    $data = [
        'transferCode' => $transferCode,
        'totalCost' => $totalCost
    ];

    // CREATE STREAM CONTEXT POST REQUEST
    // Tells file_get_contents to act as POST client
    $options = [
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'content' => json_encode($data)
        ]
    ];
    $context = stream_context_create($options);

    // SEND REQUEST AND GET RESPONSE
    $response = file_get_contents($url, false, $context);

    // HANDLE RESPONSE
    if ($response === false) {
        return false;
    }

    // CONVERT RESPONSE TO ASSOC ARRAY
    $result = json_decode($response, true);

    if (isset($result['error']) || !isset($result['transferCode'])) {
        echo "Transfer code is not valid.";
        return false;
    }

    return true;
}



//////////////////////////////////////////////////


// GET ACCOUNT INFO
function getAccountInfo(string $user, string $apiKey): ?array
{
    $url = 'https://www.yrgopelag.se/centralbank/accountInfo';

    // PREPARE DATA TO SEND
    $userInfo = [
        'user' => $user,
        'api_key' => $apiKey
    ];

    // CREATE STREAM CONTEXT POST REQUEST
    // Tells file_get_contents to act as POST client
    $options = [
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'content' => json_encode($userInfo),
        ]
    ];
    $context = stream_context_create($options);

    // SEND REQUEST AND GET RESPONSE
    $response = file_get_contents($url, false, $context);

    // HANDLE RESPONSE
    if ($response === false) {
        echo "ERROR";
        return null;
    }

    // CONVERT RESPONSE TO ASSOC ARRAY
    $data = json_decode($response, true);

    if ($data === null) {
        echo "ERROR";
        return null;
    }

    return $data;
}


/////////////////////////////////////////////////